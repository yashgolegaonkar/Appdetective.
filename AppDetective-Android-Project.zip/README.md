# App Detective (Android / Kotlin)

A small native Android starter project with a dark UI.

## What it does
- Lists launchable apps visible to the app.
- Records package removals received after App Detective is installed.
- Stores records locally using SharedPreferences.
- Ignores package replacement broadcasts (such as app updates).

## Important limitation: past uninstall history
Android does not provide ordinary third-party apps with a general API to retrieve a complete list of apps uninstalled before installation. This project does not pretend otherwise. The starter build cannot reconstruct past removals. A future import feature could accept a user-exported CSV or other history file.

## Build
1. Open this folder in Android Studio (Giraffe or newer).
2. Allow Gradle sync; use JDK 17.
3. Build > Build Bundle(s) / APK(s) > Build APK(s).
4. APK output: `app/build/outputs/apk/debug/app-debug.apk`.

The app has no third-party dependencies, so the APK should be far below 100 MB. Actual size depends on Android Gradle Plugin and build configuration.

## Permissions
`QUERY_ALL_PACKAGES` is used to list installed launchable apps. Google Play restricts broad package visibility to approved core use cases; distribution may require policy review. The package-removal receiver records future removals where Android delivers the broadcast.

## Compatibility
- Minimum Android: 6.0 (API 23)
- Target SDK: 35
