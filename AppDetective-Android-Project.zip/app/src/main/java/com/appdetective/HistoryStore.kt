package com.appdetective

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class UninstallRecord(val packageName: String, val appName: String, val time: Long)

object HistoryStore {
    private const val PREFS = "app_detective_history"
    private const val KEY = "records"

    fun add(context: Context, packageName: String) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val records = JSONArray(prefs.getString(KEY, "[]"))
        // Avoid duplicate broadcasts for the same package/time window.
        val now = System.currentTimeMillis()
        for (i in 0 until records.length()) {
            val item = records.getJSONObject(i)
            if (item.optString("packageName") == packageName &&
                now - item.optLong("time") < 60_000L) return
        }
        records.put(JSONObject().apply {
            put("packageName", packageName)
            put("appName", packageName.substringAfterLast('.'))
            put("time", now)
        })
        prefs.edit().putString(KEY, records.toString()).apply()
    }

    fun all(context: Context): List<UninstallRecord> {
        val array = JSONArray(context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getString(KEY, "[]"))
        return (0 until array.length()).map { i ->
            val o = array.getJSONObject(i)
            UninstallRecord(o.optString("packageName"), o.optString("appName"), o.optLong("time"))
        }.sortedByDescending { it.time }
    }
}
