package com.appdetective

import android.app.Activity
import android.content.pm.ApplicationInfo
import android.os.Bundle
import android.view.Gravity
import android.view.ViewGroup
import android.widget.*
import java.text.DateFormat
import java.util.Date

class MainActivity : Activity() {
    private val bg = 0xFF10111A.toInt()
    private val panel = 0xFF1B1D2A.toInt()
    private val purple = 0xFF9B8CFF.toInt()
    private lateinit var content: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = bg
        render()
    }

    private fun render() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            setPadding(22, 28, 22, 20)
        }
        val scroll = ScrollView(this)
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scroll.addView(content)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        content.addView(label("APP DETECTIVE", 25, 0xFFFFFFFF.toInt(), true))
        content.addView(label("Your app activity dashboard", 14, 0xFFAAAABD.toInt()))
        content.addView(space(20))
        val records = HistoryStore.all(this)
        content.addView(card("UNINSTALL HISTORY", "${records.size} recorded removals"))
        content.addView(space(12))
        content.addView(card("PAST HISTORY", "Android does not expose a complete uninstall archive to ordinary apps. Importing an old record is not yet supported in this starter build."))
        content.addView(space(12))
        content.addView(label("RECORDED UNINSTALLS", 17, 0xFFFFFFFF.toInt(), true))
        if (records.isEmpty()) {
            content.addView(card("No uninstall records yet", "App Detective starts recording after installation."))
        } else {
            records.forEach { r ->
                val date = DateFormat.getDateTimeInstance().format(Date(r.time))
                content.addView(card(r.appName, "${r.packageName}\n$date"))
                content.addView(space(8))
            }
        }
        content.addView(space(16))
        content.addView(label("INSTALLED APPS", 17, 0xFFFFFFFF.toInt(), true))
        val apps = packageManager.getInstalledApplications(0)
            .filter { packageManager.getLaunchIntentForPackage(it.packageName) != null }
            .sortedBy { packageManager.getApplicationLabel(it).toString().lowercase() }
        content.addView(card("Currently visible apps", "${apps.size} apps found"))
        apps.forEach { info ->
            val name = packageManager.getApplicationLabel(info).toString()
            content.addView(card(name, info.packageName))
            content.addView(space(6))
        }
        content.addView(space(12))
        content.addView(label("Privacy: records stay on this device.", 12, 0xFFAAAABD.toInt()))
        setContentView(root)
    }

    private fun label(text: String, size: Int, color: Int, bold: Boolean = false) =
        TextView(this).apply {
            this.text = text
            textSize = size.toFloat()
            setTextColor(color)
            if (bold) setTypeface(null, android.graphics.Typeface.BOLD)
            setPadding(0, 5, 0, 5)
        }

    private fun card(title: String, subtitle: String): LinearLayout {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 13, 16, 13)
            setBackgroundColor(panel)
        }
        box.addView(label(title, 16, 0xFFFFFFFF.toInt(), true))
        box.addView(label(subtitle, 12, 0xFFB9B9C9.toInt()))
        return box
    }

    private fun space(height: Int) = Space(this).apply {
        layoutParams = ViewGroup.LayoutParams(1, height)
    }
}
